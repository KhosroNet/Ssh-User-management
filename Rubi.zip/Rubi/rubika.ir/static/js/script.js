/*!
 * Bootstrap util.js v4.6.0 (https://getbootstrap.com/)
 * Copyright 2011-2021 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function (global, factory) {
	typeof exports === "object" && typeof module !== "undefined"
		? (module.exports = factory(require("jquery")))
		: typeof define === "function" && define.amd
			? define(["jquery"], factory)
			: ((global =
				typeof globalThis !== "undefined" ? globalThis : global || self),
				(global.Util = factory(global.jQuery)));
})(this, function ($) {
	"use strict";

	function _interopDefaultLegacy(e) {
		return e && typeof e === "object" && "default" in e ? e : { default: e };
	}

	var $__default = /*#__PURE__*/ _interopDefaultLegacy($);

	/**
	 * --------------------------------------------------------------------------
	 * Bootstrap (v4.6.0): util.js
	 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
	 * --------------------------------------------------------------------------
	 */
	/**
	 * ------------------------------------------------------------------------
	 * Private TransitionEnd Helpers
	 * ------------------------------------------------------------------------
	 */

	var TRANSITION_END = "transitionend";
	var MAX_UID = 1000000;
	var MILLISECONDS_MULTIPLIER = 1000; // Shoutout AngusCroll (https://goo.gl/pxwQGp)

	function toType(obj) {
		if (obj === null || typeof obj === "undefined") {
			return "" + obj;
		}

		return {}.toString
			.call(obj)
			.match(/\s([a-z]+)/i)[1]
			.toLowerCase();
	}

	function getSpecialTransitionEndEvent() {
		return {
			bindType: TRANSITION_END,
			delegateType: TRANSITION_END,
			handle: function handle(event) {
				if ($__default["default"](event.target).is(this)) {
					return event.handleObj.handler.apply(this, arguments); // eslint-disable-line prefer-rest-params
				}

				return undefined;
			},
		};
	}

	function transitionEndEmulator(duration) {
		var _this = this;

		var called = false;
		$__default["default"](this).one(Util.TRANSITION_END, function () {
			called = true;
		});
		setTimeout(function () {
			if (!called) {
				Util.triggerTransitionEnd(_this);
			}
		}, duration);
		return this;
	}

	function setTransitionEndSupport() {
		$__default["default"].fn.emulateTransitionEnd = transitionEndEmulator;
		$__default["default"].event.special[Util.TRANSITION_END] =
			getSpecialTransitionEndEvent();
	}
	/**
	 * --------------------------------------------------------------------------
	 * Public Util Api
	 * --------------------------------------------------------------------------
	 */

	var Util = {
		TRANSITION_END: "bsTransitionEnd",
		getUID: function getUID(prefix) {
			do {
				prefix += ~~(Math.random() * MAX_UID); // "~~" acts like a faster Math.floor() here
			} while (document.getElementById(prefix));

			return prefix;
		},
		getSelectorFromElement: function getSelectorFromElement(element) {
			var selector = element.getAttribute("data-target");

			if (!selector || selector === "#") {
				var hrefAttr = element.getAttribute("href");
				selector = hrefAttr && hrefAttr !== "#" ? hrefAttr.trim() : "";
			}

			try {
				return document.querySelector(selector) ? selector : null;
			} catch (_) {
				return null;
			}
		},
		getTransitionDurationFromElement: function getTransitionDurationFromElement(
			element
		) {
			if (!element) {
				return 0;
			} // Get transition-duration of the element

			var transitionDuration = $__default["default"](element).css(
				"transition-duration"
			);
			var transitionDelay =
				$__default["default"](element).css("transition-delay");
			var floatTransitionDuration = parseFloat(transitionDuration);
			var floatTransitionDelay = parseFloat(transitionDelay); // Return 0 if element or transition duration is not found

			if (!floatTransitionDuration && !floatTransitionDelay) {
				return 0;
			} // If multiple durations are defined, take the first

			transitionDuration = transitionDuration.split(",")[0];
			transitionDelay = transitionDelay.split(",")[0];
			return (
				(parseFloat(transitionDuration) + parseFloat(transitionDelay)) *
				MILLISECONDS_MULTIPLIER
			);
		},
		reflow: function reflow(element) {
			return element.offsetHeight;
		},
		triggerTransitionEnd: function triggerTransitionEnd(element) {
			$__default["default"](element).trigger(TRANSITION_END);
		},
		supportsTransitionEnd: function supportsTransitionEnd() {
			return Boolean(TRANSITION_END);
		},
		isElement: function isElement(obj) {
			return (obj[0] || obj).nodeType;
		},
		typeCheckConfig: function typeCheckConfig(
			componentName,
			config,
			configTypes
		) {
			for (var property in configTypes) {
				if (Object.prototype.hasOwnProperty.call(configTypes, property)) {
					var expectedTypes = configTypes[property];
					var value = config[property];
					var valueType =
						value && Util.isElement(value) ? "element" : toType(value);

					if (!new RegExp(expectedTypes).test(valueType)) {
						throw new Error(
							componentName.toUpperCase() +
							": " +
							('Option "' +
								property +
								'" provided type "' +
								valueType +
								'" ') +
							('but expected type "' + expectedTypes + '".')
						);
					}
				}
			}
		},
		findShadowRoot: function findShadowRoot(element) {
			if (!document.documentElement.attachShadow) {
				return null;
			} // Can find the shadow root otherwise it'll return the document

			if (typeof element.getRootNode === "function") {
				var root = element.getRootNode();
				return root instanceof ShadowRoot ? root : null;
			}

			if (element instanceof ShadowRoot) {
				return element;
			} // when we don't find a shadow root

			if (!element.parentNode) {
				return null;
			}

			return Util.findShadowRoot(element.parentNode);
		},
		jQueryDetection: function jQueryDetection() {
			if (typeof $__default["default"] === "undefined") {
				throw new TypeError(
					"Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript."
				);
			}

			var version = $__default["default"].fn.jquery.split(" ")[0].split(".");
			var minMajor = 1;
			var ltMajor = 2;
			var minMinor = 9;
			var minPatch = 1;
			var maxMajor = 4;

			if (
				(version[0] < ltMajor && version[1] < minMinor) ||
				(version[0] === minMajor &&
					version[1] === minMinor &&
					version[2] < minPatch) ||
				version[0] >= maxMajor
			) {
				throw new Error(
					"Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0"
				);
			}
		},
	};
	Util.jQueryDetection();
	setTransitionEndSupport();

	return Util;
});

/*!
 * Bootstrap modal.js v4.6.0 (https://getbootstrap.com/)
 * Copyright 2011-2021 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function (global, factory) {
	typeof exports === "object" && typeof module !== "undefined"
		? (module.exports = factory(require("jquery"), require("./util.js")))
		: typeof define === "function" && define.amd
			? define(["jquery", "./util"], factory)
			: ((global =
				typeof globalThis !== "undefined" ? globalThis : global || self),
				(global.Modal = factory(global.jQuery, global.Util)));
})(this, function ($, Util) {
	"use strict";

	function _interopDefaultLegacy(e) {
		return e && typeof e === "object" && "default" in e ? e : { default: e };
	}

	var $__default = /*#__PURE__*/ _interopDefaultLegacy($);
	var Util__default = /*#__PURE__*/ _interopDefaultLegacy(Util);

	function _defineProperties(target, props) {
		for (var i = 0; i < props.length; i++) {
			var descriptor = props[i];
			descriptor.enumerable = descriptor.enumerable || false;
			descriptor.configurable = true;
			if ("value" in descriptor) descriptor.writable = true;
			Object.defineProperty(target, descriptor.key, descriptor);
		}
	}

	function _createClass(Constructor, protoProps, staticProps) {
		if (protoProps) _defineProperties(Constructor.prototype, protoProps);
		if (staticProps) _defineProperties(Constructor, staticProps);
		return Constructor;
	}

	function _extends() {
		_extends =
			Object.assign ||
			function (target) {
				for (var i = 1; i < arguments.length; i++) {
					var source = arguments[i];

					for (var key in source) {
						if (Object.prototype.hasOwnProperty.call(source, key)) {
							target[key] = source[key];
						}
					}
				}

				return target;
			};

		return _extends.apply(this, arguments);
	}

	/**
	 * ------------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------------
	 */

	var NAME = "modal";
	var VERSION = "4.6.0";
	var DATA_KEY = "bs.modal";
	var EVENT_KEY = "." + DATA_KEY;
	var DATA_API_KEY = ".data-api";
	var JQUERY_NO_CONFLICT = $__default["default"].fn[NAME];
	var ESCAPE_KEYCODE = 27; // KeyboardEvent.which value for Escape (Esc) key

	var Default = {
		backdrop: true,
		keyboard: true,
		focus: true,
		show: true,
	};
	var DefaultType = {
		backdrop: "(boolean|string)",
		keyboard: "boolean",
		focus: "boolean",
		show: "boolean",
	};
	var EVENT_HIDE = "hide" + EVENT_KEY;
	var EVENT_HIDE_PREVENTED = "hidePrevented" + EVENT_KEY;
	var EVENT_HIDDEN = "hidden" + EVENT_KEY;
	var EVENT_SHOW = "show" + EVENT_KEY;
	var EVENT_SHOWN = "shown" + EVENT_KEY;
	var EVENT_FOCUSIN = "focusin" + EVENT_KEY;
	var EVENT_RESIZE = "resize" + EVENT_KEY;
	var EVENT_CLICK_DISMISS = "click.dismiss" + EVENT_KEY;
	var EVENT_KEYDOWN_DISMISS = "keydown.dismiss" + EVENT_KEY;
	var EVENT_MOUSEUP_DISMISS = "mouseup.dismiss" + EVENT_KEY;
	var EVENT_MOUSEDOWN_DISMISS = "mousedown.dismiss" + EVENT_KEY;
	var EVENT_CLICK_DATA_API = "click" + EVENT_KEY + DATA_API_KEY;
	var CLASS_NAME_SCROLLABLE = "modal-dialog-scrollable";
	var CLASS_NAME_SCROLLBAR_MEASURER = "modal-scrollbar-measure";
	var CLASS_NAME_BACKDROP = "modal-backdrop";
	var CLASS_NAME_OPEN = "modal-open";
	var CLASS_NAME_FADE = "fade";
	var CLASS_NAME_SHOW = "show";
	var CLASS_NAME_STATIC = "modal-static";
	var SELECTOR_DIALOG = ".modal-dialog";
	var SELECTOR_MODAL_BODY = ".modal-body";
	var SELECTOR_DATA_TOGGLE = '[data-toggle="modal"]';
	var SELECTOR_DATA_DISMISS = '[data-dismiss="modal"]';
	var SELECTOR_FIXED_CONTENT =
		".fixed-top, .fixed-bottom, .is-fixed, .sticky-top";
	var SELECTOR_STICKY_CONTENT = ".sticky-top";
	/**
	 * ------------------------------------------------------------------------
	 * Class Definition
	 * ------------------------------------------------------------------------
	 */

	var Modal = /*#__PURE__*/ (function () {
		function Modal(element, config) {
			this._config = this._getConfig(config);
			this._element = element;
			this._dialog = element.querySelector(SELECTOR_DIALOG);
			this._backdrop = null;
			this._isShown = false;
			this._isBodyOverflowing = false;
			this._ignoreBackdropClick = false;
			this._isTransitioning = false;
			this._scrollbarWidth = 0;
		} // Getters

		var _proto = Modal.prototype;

		// Public
		_proto.toggle = function toggle(relatedTarget) {
			return this._isShown ? this.hide() : this.show(relatedTarget);
		};

		_proto.show = function show(relatedTarget) {
			var _this = this;

			if (this._isShown || this._isTransitioning) {
				return;
			}

			if ($__default["default"](this._element).hasClass(CLASS_NAME_FADE)) {
				this._isTransitioning = true;
			}

			var showEvent = $__default["default"].Event(EVENT_SHOW, {
				relatedTarget: relatedTarget,
			});
			$__default["default"](this._element).trigger(showEvent);

			if (this._isShown || showEvent.isDefaultPrevented()) {
				return;
			}

			this._isShown = true;

			this._checkScrollbar();

			this._setScrollbar();

			this._adjustDialog();

			this._setEscapeEvent();

			this._setResizeEvent();

			$__default["default"](this._element).on(
				EVENT_CLICK_DISMISS,
				SELECTOR_DATA_DISMISS,
				function (event) {
					return _this.hide(event);
				}
			);
			$__default["default"](this._dialog).on(
				EVENT_MOUSEDOWN_DISMISS,
				function () {
					$__default["default"](_this._element).one(
						EVENT_MOUSEUP_DISMISS,
						function (event) {
							if ($__default["default"](event.target).is(_this._element)) {
								_this._ignoreBackdropClick = true;
							}
						}
					);
				}
			);

			this._showBackdrop(function () {
				return _this._showElement(relatedTarget);
			});
		};

		_proto.hide = function hide(event) {
			var _this2 = this;

			if (event) {
				event.preventDefault();
			}

			if (!this._isShown || this._isTransitioning) {
				return;
			}

			var hideEvent = $__default["default"].Event(EVENT_HIDE);
			$__default["default"](this._element).trigger(hideEvent);

			if (!this._isShown || hideEvent.isDefaultPrevented()) {
				return;
			}

			this._isShown = false;
			var transition = $__default["default"](this._element).hasClass(
				CLASS_NAME_FADE
			);

			if (transition) {
				this._isTransitioning = true;
			}

			this._setEscapeEvent();

			this._setResizeEvent();

			$__default["default"](document).off(EVENT_FOCUSIN);
			$__default["default"](this._element).removeClass(CLASS_NAME_SHOW);
			$__default["default"](this._element).off(EVENT_CLICK_DISMISS);
			$__default["default"](this._dialog).off(EVENT_MOUSEDOWN_DISMISS);

			if (transition) {
				var transitionDuration = Util__default[
					"default"
				].getTransitionDurationFromElement(this._element);
				$__default["default"](this._element)
					.one(Util__default["default"].TRANSITION_END, function (event) {
						return _this2._hideModal(event);
					})
					.emulateTransitionEnd(transitionDuration);
			} else {
				this._hideModal();
			}
		};

		_proto.dispose = function dispose() {
			[window, this._element, this._dialog].forEach(function (htmlElement) {
				return $__default["default"](htmlElement).off(EVENT_KEY);
			});
			/**
			 * `document` has 2 events `EVENT_FOCUSIN` and `EVENT_CLICK_DATA_API`
			 * Do not move `document` in `htmlElements` array
			 * It will remove `EVENT_CLICK_DATA_API` event that should remain
			 */

			$__default["default"](document).off(EVENT_FOCUSIN);
			$__default["default"].removeData(this._element, DATA_KEY);
			this._config = null;
			this._element = null;
			this._dialog = null;
			this._backdrop = null;
			this._isShown = null;
			this._isBodyOverflowing = null;
			this._ignoreBackdropClick = null;
			this._isTransitioning = null;
			this._scrollbarWidth = null;
		};

		_proto.handleUpdate = function handleUpdate() {
			this._adjustDialog();
		}; // Private

		_proto._getConfig = function _getConfig(config) {
			config = _extends({}, Default, config);
			Util__default["default"].typeCheckConfig(NAME, config, DefaultType);
			return config;
		};

		_proto._triggerBackdropTransition = function _triggerBackdropTransition() {
			var _this3 = this;

			var hideEventPrevented =
				$__default["default"].Event(EVENT_HIDE_PREVENTED);
			$__default["default"](this._element).trigger(hideEventPrevented);

			if (hideEventPrevented.isDefaultPrevented()) {
				return;
			}

			var isModalOverflowing =
				this._element.scrollHeight > document.documentElement.clientHeight;

			if (!isModalOverflowing) {
				this._element.style.overflowY = "hidden";
			}

			this._element.classList.add(CLASS_NAME_STATIC);

			var modalTransitionDuration = Util__default[
				"default"
			].getTransitionDurationFromElement(this._dialog);
			$__default["default"](this._element).off(
				Util__default["default"].TRANSITION_END
			);
			$__default["default"](this._element)
				.one(Util__default["default"].TRANSITION_END, function () {
					_this3._element.classList.remove(CLASS_NAME_STATIC);

					if (!isModalOverflowing) {
						$__default["default"](_this3._element)
							.one(Util__default["default"].TRANSITION_END, function () {
								_this3._element.style.overflowY = "";
							})
							.emulateTransitionEnd(_this3._element, modalTransitionDuration);
					}
				})
				.emulateTransitionEnd(modalTransitionDuration);

			this._element.focus();
		};

		_proto._showElement = function _showElement(relatedTarget) {
			var _this4 = this;

			var transition = $__default["default"](this._element).hasClass(
				CLASS_NAME_FADE
			);
			var modalBody = this._dialog
				? this._dialog.querySelector(SELECTOR_MODAL_BODY)
				: null;

			if (
				!this._element.parentNode ||
				this._element.parentNode.nodeType !== Node.ELEMENT_NODE
			) {
				// Don't move modal's DOM position
				document.body.appendChild(this._element);
			}

			this._element.style.display = "block";

			this._element.removeAttribute("aria-hidden");

			this._element.setAttribute("aria-modal", true);

			this._element.setAttribute("role", "dialog");

			if (
				$__default["default"](this._dialog).hasClass(CLASS_NAME_SCROLLABLE) &&
				modalBody
			) {
				modalBody.scrollTop = 0;
			} else {
				this._element.scrollTop = 0;
			}

			if (transition) {
				Util__default["default"].reflow(this._element);
			}

			$__default["default"](this._element).addClass(CLASS_NAME_SHOW);

			if (this._config.focus) {
				this._enforceFocus();
			}

			var shownEvent = $__default["default"].Event(EVENT_SHOWN, {
				relatedTarget: relatedTarget,
			});

			var transitionComplete = function transitionComplete() {
				if (_this4._config.focus) {
					_this4._element.focus();
				}

				_this4._isTransitioning = false;
				$__default["default"](_this4._element).trigger(shownEvent);
			};

			if (transition) {
				var transitionDuration = Util__default[
					"default"
				].getTransitionDurationFromElement(this._dialog);
				$__default["default"](this._dialog)
					.one(Util__default["default"].TRANSITION_END, transitionComplete)
					.emulateTransitionEnd(transitionDuration);
			} else {
				transitionComplete();
			}
		};

		_proto._enforceFocus = function _enforceFocus() {
			var _this5 = this;

			$__default["default"](document)
				.off(EVENT_FOCUSIN) // Guard against infinite focus loop
				.on(EVENT_FOCUSIN, function (event) {
					if (
						document !== event.target &&
						_this5._element !== event.target &&
						$__default["default"](_this5._element).has(event.target).length ===
						0
					) {
						_this5._element.focus();
					}
				});
		};

		_proto._setEscapeEvent = function _setEscapeEvent() {
			var _this6 = this;

			if (this._isShown) {
				$__default["default"](this._element).on(
					EVENT_KEYDOWN_DISMISS,
					function (event) {
						if (_this6._config.keyboard && event.which === ESCAPE_KEYCODE) {
							event.preventDefault();

							_this6.hide();
						} else if (
							!_this6._config.keyboard &&
							event.which === ESCAPE_KEYCODE
						) {
							_this6._triggerBackdropTransition();
						}
					}
				);
			} else if (!this._isShown) {
				$__default["default"](this._element).off(EVENT_KEYDOWN_DISMISS);
			}
		};

		_proto._setResizeEvent = function _setResizeEvent() {
			var _this7 = this;

			if (this._isShown) {
				$__default["default"](window).on(EVENT_RESIZE, function (event) {
					return _this7.handleUpdate(event);
				});
			} else {
				$__default["default"](window).off(EVENT_RESIZE);
			}
		};

		_proto._hideModal = function _hideModal() {
			var _this8 = this;

			this._element.style.display = "none";

			this._element.setAttribute("aria-hidden", true);

			this._element.removeAttribute("aria-modal");

			this._element.removeAttribute("role");

			this._isTransitioning = false;

			this._showBackdrop(function () {
				$__default["default"](document.body).removeClass(CLASS_NAME_OPEN);

				_this8._resetAdjustments();

				_this8._resetScrollbar();

				$__default["default"](_this8._element).trigger(EVENT_HIDDEN);
			});
		};

		_proto._removeBackdrop = function _removeBackdrop() {
			if (this._backdrop) {
				$__default["default"](this._backdrop).remove();
				this._backdrop = null;
			}
		};

		_proto._showBackdrop = function _showBackdrop(callback) {
			var _this9 = this;

			var animate = $__default["default"](this._element).hasClass(
				CLASS_NAME_FADE
			)
				? CLASS_NAME_FADE
				: "";

			if (this._isShown && this._config.backdrop) {
				this._backdrop = document.createElement("div");
				this._backdrop.className = CLASS_NAME_BACKDROP;

				if (animate) {
					this._backdrop.classList.add(animate);
				}

				$__default["default"](this._backdrop).appendTo(document.body);
				$__default["default"](this._element).on(
					EVENT_CLICK_DISMISS,
					function (event) {
						if (_this9._ignoreBackdropClick) {
							_this9._ignoreBackdropClick = false;
							return;
						}

						if (event.target !== event.currentTarget) {
							return;
						}

						if (_this9._config.backdrop === "static") {
							_this9._triggerBackdropTransition();
						} else {
							_this9.hide();
						}
					}
				);

				if (animate) {
					Util__default["default"].reflow(this._backdrop);
				}

				$__default["default"](this._backdrop).addClass(CLASS_NAME_SHOW);

				if (!callback) {
					return;
				}

				if (!animate) {
					callback();
					return;
				}

				var backdropTransitionDuration = Util__default[
					"default"
				].getTransitionDurationFromElement(this._backdrop);
				$__default["default"](this._backdrop)
					.one(Util__default["default"].TRANSITION_END, callback)
					.emulateTransitionEnd(backdropTransitionDuration);
			} else if (!this._isShown && this._backdrop) {
				$__default["default"](this._backdrop).removeClass(CLASS_NAME_SHOW);

				var callbackRemove = function callbackRemove() {
					_this9._removeBackdrop();

					if (callback) {
						callback();
					}
				};

				if ($__default["default"](this._element).hasClass(CLASS_NAME_FADE)) {
					var _backdropTransitionDuration = Util__default[
						"default"
					].getTransitionDurationFromElement(this._backdrop);

					$__default["default"](this._backdrop)
						.one(Util__default["default"].TRANSITION_END, callbackRemove)
						.emulateTransitionEnd(_backdropTransitionDuration);
				} else {
					callbackRemove();
				}
			} else if (callback) {
				callback();
			}
		}; // ----------------------------------------------------------------------
		// the following methods are used to handle overflowing modals
		// todo (fat): these should probably be refactored out of modal.js
		// ----------------------------------------------------------------------

		_proto._adjustDialog = function _adjustDialog() {
			var isModalOverflowing =
				this._element.scrollHeight > document.documentElement.clientHeight;

			if (!this._isBodyOverflowing && isModalOverflowing) {
				this._element.style.paddingLeft = this._scrollbarWidth + "px";
			}

			if (this._isBodyOverflowing && !isModalOverflowing) {
				this._element.style.paddingRight = this._scrollbarWidth + "px";
			}
		};

		_proto._resetAdjustments = function _resetAdjustments() {
			this._element.style.paddingLeft = "";
			this._element.style.paddingRight = "";
		};

		_proto._checkScrollbar = function _checkScrollbar() {
			var rect = document.body.getBoundingClientRect();
			this._isBodyOverflowing =
				Math.round(rect.left + rect.right) < window.innerWidth;
			this._scrollbarWidth = this._getScrollbarWidth();
		};

		_proto._setScrollbar = function _setScrollbar() {
			var _this10 = this;

			if (this._isBodyOverflowing) {
				// Note: DOMNode.style.paddingRight returns the actual value or '' if not set
				//   while $(DOMNode).css('padding-right') returns the calculated value or 0 if not set
				var fixedContent = [].slice.call(
					document.querySelectorAll(SELECTOR_FIXED_CONTENT)
				);
				var stickyContent = [].slice.call(
					document.querySelectorAll(SELECTOR_STICKY_CONTENT)
				); // Adjust fixed content padding

				$__default["default"](fixedContent).each(function (index, element) {
					var actualPadding = element.style.paddingRight;
					var calculatedPadding =
						$__default["default"](element).css("padding-right");
					$__default["default"](element)
						.data("padding-right", actualPadding)
						.css(
							"padding-right",
							parseFloat(calculatedPadding) + _this10._scrollbarWidth + "px"
						);
				}); // Adjust sticky content margin

				$__default["default"](stickyContent).each(function (index, element) {
					var actualMargin = element.style.marginRight;
					var calculatedMargin =
						$__default["default"](element).css("margin-right");
					$__default["default"](element)
						.data("margin-right", actualMargin)
						.css(
							"margin-right",
							parseFloat(calculatedMargin) - _this10._scrollbarWidth + "px"
						);
				}); // Adjust body padding

				var actualPadding = document.body.style.paddingRight;
				var calculatedPadding = $__default["default"](document.body).css(
					"padding-right"
				);
				$__default["default"](document.body)
					.data("padding-right", actualPadding)
					.css(
						"padding-right",
						parseFloat(calculatedPadding) + this._scrollbarWidth + "px"
					);
			}

			$__default["default"](document.body).addClass(CLASS_NAME_OPEN);
		};

		_proto._resetScrollbar = function _resetScrollbar() {
			// Restore fixed content padding
			var fixedContent = [].slice.call(
				document.querySelectorAll(SELECTOR_FIXED_CONTENT)
			);
			$__default["default"](fixedContent).each(function (index, element) {
				var padding = $__default["default"](element).data("padding-right");
				$__default["default"](element).removeData("padding-right");
				element.style.paddingRight = padding ? padding : "";
			}); // Restore sticky content

			var elements = [].slice.call(
				document.querySelectorAll("" + SELECTOR_STICKY_CONTENT)
			);
			$__default["default"](elements).each(function (index, element) {
				var margin = $__default["default"](element).data("margin-right");

				if (typeof margin !== "undefined") {
					$__default["default"](element)
						.css("margin-right", margin)
						.removeData("margin-right");
				}
			}); // Restore body padding

			var padding = $__default["default"](document.body).data("padding-right");
			$__default["default"](document.body).removeData("padding-right");
			document.body.style.paddingRight = padding ? padding : "";
		};

		_proto._getScrollbarWidth = function _getScrollbarWidth() {
			// thx d.walsh
			var scrollDiv = document.createElement("div");
			scrollDiv.className = CLASS_NAME_SCROLLBAR_MEASURER;
			document.body.appendChild(scrollDiv);
			var scrollbarWidth =
				scrollDiv.getBoundingClientRect().width - scrollDiv.clientWidth;
			document.body.removeChild(scrollDiv);
			return scrollbarWidth;
		}; // Static

		Modal._jQueryInterface = function _jQueryInterface(config, relatedTarget) {
			return this.each(function () {
				var data = $__default["default"](this).data(DATA_KEY);

				var _config = _extends(
					{},
					Default,
					$__default["default"](this).data(),
					typeof config === "object" && config ? config : {}
				);

				if (!data) {
					data = new Modal(this, _config);
					$__default["default"](this).data(DATA_KEY, data);
				}

				if (typeof config === "string") {
					if (typeof data[config] === "undefined") {
						throw new TypeError('No method named "' + config + '"');
					}

					data[config](relatedTarget);
				} else if (_config.show) {
					data.show(relatedTarget);
				}
			});
		};

		_createClass(Modal, null, [
			{
				key: "VERSION",
				get: function get() {
					return VERSION;
				},
			},
			{
				key: "Default",
				get: function get() {
					return Default;
				},
			},
		]);

		return Modal;
	})();
	/**
	 * ------------------------------------------------------------------------
	 * Data Api implementation
	 * ------------------------------------------------------------------------
	 */

	$__default["default"](document).on(
		EVENT_CLICK_DATA_API,
		SELECTOR_DATA_TOGGLE,
		function (event) {
			var _this11 = this;

			var target;
			var selector = Util__default["default"].getSelectorFromElement(this);

			if (selector) {
				target = document.querySelector(selector);
			}

			var config = $__default["default"](target).data(DATA_KEY)
				? "toggle"
				: _extends(
					{},
					$__default["default"](target).data(),
					$__default["default"](this).data()
				);

			if (this.tagName === "A" || this.tagName === "AREA") {
				event.preventDefault();
			}

			var $target = $__default["default"](target).one(
				EVENT_SHOW,
				function (showEvent) {
					if (showEvent.isDefaultPrevented()) {
						// Only register focus restorer if modal will actually get shown
						return;
					}

					$target.one(EVENT_HIDDEN, function () {
						if ($__default["default"](_this11).is(":visible")) {
							_this11.focus();
						}
					});
				}
			);

			Modal._jQueryInterface.call($__default["default"](target), config, this);
		}
	);
	/**
	 * ------------------------------------------------------------------------
	 * jQuery
	 * ------------------------------------------------------------------------
	 */

	$__default["default"].fn[NAME] = Modal._jQueryInterface;
	$__default["default"].fn[NAME].Constructor = Modal;

	$__default["default"].fn[NAME].noConflict = function () {
		$__default["default"].fn[NAME] = JQUERY_NO_CONFLICT;
		return Modal._jQueryInterface;
	};

	return Modal;
});


(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('jquery'), require('./util.js')) :
		typeof define === 'function' && define.amd ? define(['jquery', './util'], factory) :
			(global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.Tab = factory(global.jQuery, global.Util));
}(this, (function ($, Util) {
	'use strict';

	function _interopDefaultLegacy(e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

	var $__default = /*#__PURE__*/_interopDefaultLegacy($);
	var Util__default = /*#__PURE__*/_interopDefaultLegacy(Util);

	function _defineProperties(target, props) {
		for (var i = 0; i < props.length; i++) {
			var descriptor = props[i];
			descriptor.enumerable = descriptor.enumerable || false;
			descriptor.configurable = true;
			if ("value" in descriptor) descriptor.writable = true;
			Object.defineProperty(target, descriptor.key, descriptor);
		}
	}

	function _createClass(Constructor, protoProps, staticProps) {
		if (protoProps) _defineProperties(Constructor.prototype, protoProps);
		if (staticProps) _defineProperties(Constructor, staticProps);
		return Constructor;
	}

	/**
	 * ------------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------------
	 */

	var NAME = 'tab';
	var VERSION = '4.6.0';
	var DATA_KEY = 'bs.tab';
	var EVENT_KEY = "." + DATA_KEY;
	var DATA_API_KEY = '.data-api';
	var JQUERY_NO_CONFLICT = $__default['default'].fn[NAME];
	var EVENT_HIDE = "hide" + EVENT_KEY;
	var EVENT_HIDDEN = "hidden" + EVENT_KEY;
	var EVENT_SHOW = "show" + EVENT_KEY;
	var EVENT_SHOWN = "shown" + EVENT_KEY;
	var EVENT_CLICK_DATA_API = "click" + EVENT_KEY + DATA_API_KEY;
	var CLASS_NAME_DROPDOWN_MENU = 'dropdown-menu';
	var CLASS_NAME_ACTIVE = 'active';
	var CLASS_NAME_DISABLED = 'disabled';
	var CLASS_NAME_FADE = 'fade';
	var CLASS_NAME_SHOW = 'show';
	var SELECTOR_DROPDOWN = '.dropdown';
	var SELECTOR_NAV_LIST_GROUP = '.nav, .list-group';
	var SELECTOR_ACTIVE = '.active';
	var SELECTOR_ACTIVE_UL = '> li > .active';
	var SELECTOR_DATA_TOGGLE = '[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]';
	var SELECTOR_DROPDOWN_TOGGLE = '.dropdown-toggle';
	var SELECTOR_DROPDOWN_ACTIVE_CHILD = '> .dropdown-menu .active';
	/**
	 * ------------------------------------------------------------------------
	 * Class Definition
	 * ------------------------------------------------------------------------
	 */

	var Tab = /*#__PURE__*/function () {
		function Tab(element) {
			this._element = element;
		} // Getters


		var _proto = Tab.prototype;

		// Public
		_proto.show = function show() {
			var _this = this;

			if (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && $__default['default'](this._element).hasClass(CLASS_NAME_ACTIVE) || $__default['default'](this._element).hasClass(CLASS_NAME_DISABLED)) {
				return;
			}

			var target;
			var previous;
			var listElement = $__default['default'](this._element).closest(SELECTOR_NAV_LIST_GROUP)[0];
			var selector = Util__default['default'].getSelectorFromElement(this._element);

			if (listElement) {
				var itemSelector = listElement.nodeName === 'UL' || listElement.nodeName === 'OL' ? SELECTOR_ACTIVE_UL : SELECTOR_ACTIVE;
				previous = $__default['default'].makeArray($__default['default'](listElement).find(itemSelector));
				previous = previous[previous.length - 1];
			}

			var hideEvent = $__default['default'].Event(EVENT_HIDE, {
				relatedTarget: this._element
			});
			var showEvent = $__default['default'].Event(EVENT_SHOW, {
				relatedTarget: previous
			});

			if (previous) {
				$__default['default'](previous).trigger(hideEvent);
			}

			$__default['default'](this._element).trigger(showEvent);

			if (showEvent.isDefaultPrevented() || hideEvent.isDefaultPrevented()) {
				return;
			}

			if (selector) {
				target = document.querySelector(selector);
			}

			this._activate(this._element, listElement);

			var complete = function complete() {
				var hiddenEvent = $__default['default'].Event(EVENT_HIDDEN, {
					relatedTarget: _this._element
				});
				var shownEvent = $__default['default'].Event(EVENT_SHOWN, {
					relatedTarget: previous
				});
				$__default['default'](previous).trigger(hiddenEvent);
				$__default['default'](_this._element).trigger(shownEvent);
			};

			if (target) {
				this._activate(target, target.parentNode, complete);
			} else {
				complete();
			}
		};

		_proto.dispose = function dispose() {
			$__default['default'].removeData(this._element, DATA_KEY);
			this._element = null;
		} // Private
			;

		_proto._activate = function _activate(element, container, callback) {
			var _this2 = this;

			var activeElements = container && (container.nodeName === 'UL' || container.nodeName === 'OL') ? $__default['default'](container).find(SELECTOR_ACTIVE_UL) : $__default['default'](container).children(SELECTOR_ACTIVE);
			var active = activeElements[0];
			var isTransitioning = callback && active && $__default['default'](active).hasClass(CLASS_NAME_FADE);

			var complete = function complete() {
				return _this2._transitionComplete(element, active, callback);
			};

			if (active && isTransitioning) {
				var transitionDuration = Util__default['default'].getTransitionDurationFromElement(active);
				$__default['default'](active).removeClass(CLASS_NAME_SHOW).one(Util__default['default'].TRANSITION_END, complete).emulateTransitionEnd(transitionDuration);
			} else {
				complete();
			}
		};

		_proto._transitionComplete = function _transitionComplete(element, active, callback) {
			if (active) {
				$__default['default'](active).removeClass(CLASS_NAME_ACTIVE);
				var dropdownChild = $__default['default'](active.parentNode).find(SELECTOR_DROPDOWN_ACTIVE_CHILD)[0];

				if (dropdownChild) {
					$__default['default'](dropdownChild).removeClass(CLASS_NAME_ACTIVE);
				}

				if (active.getAttribute('role') === 'tab') {
					active.setAttribute('aria-selected', false);
				}
			}

			$__default['default'](element).addClass(CLASS_NAME_ACTIVE);

			if (element.getAttribute('role') === 'tab') {
				element.setAttribute('aria-selected', true);
			}

			Util__default['default'].reflow(element);

			if (element.classList.contains(CLASS_NAME_FADE)) {
				element.classList.add(CLASS_NAME_SHOW);
			}

			if (element.parentNode && $__default['default'](element.parentNode).hasClass(CLASS_NAME_DROPDOWN_MENU)) {
				var dropdownElement = $__default['default'](element).closest(SELECTOR_DROPDOWN)[0];

				if (dropdownElement) {
					var dropdownToggleList = [].slice.call(dropdownElement.querySelectorAll(SELECTOR_DROPDOWN_TOGGLE));
					$__default['default'](dropdownToggleList).addClass(CLASS_NAME_ACTIVE);
				}

				element.setAttribute('aria-expanded', true);
			}

			if (callback) {
				callback();
			}
		} // Static
			;

		Tab._jQueryInterface = function _jQueryInterface(config) {
			return this.each(function () {
				var $this = $__default['default'](this);
				var data = $this.data(DATA_KEY);

				if (!data) {
					data = new Tab(this);
					$this.data(DATA_KEY, data);
				}

				if (typeof config === 'string') {
					if (typeof data[config] === 'undefined') {
						throw new TypeError("No method named \"" + config + "\"");
					}

					data[config]();
				}
			});
		};

		_createClass(Tab, null, [{
			key: "VERSION",
			get: function get() {
				return VERSION;
			}
		}]);

		return Tab;
	}();
	/**
	 * ------------------------------------------------------------------------
	 * Data Api implementation
	 * ------------------------------------------------------------------------
	 */


	$__default['default'](document).on(EVENT_CLICK_DATA_API, SELECTOR_DATA_TOGGLE, function (event) {
		event.preventDefault();

		Tab._jQueryInterface.call($__default['default'](this), 'show');
	});
	/**
	 * ------------------------------------------------------------------------
	 * jQuery
	 * ------------------------------------------------------------------------
	 */

	$__default['default'].fn[NAME] = Tab._jQueryInterface;
	$__default['default'].fn[NAME].Constructor = Tab;

	$__default['default'].fn[NAME].noConflict = function () {
		$__default['default'].fn[NAME] = JQUERY_NO_CONFLICT;
		return Tab._jQueryInterface;
	};

	return Tab;

})));

/*!
 * Bootstrap collapse.js v4.6.0 (https://getbootstrap.com/)
 * Copyright 2011-2021 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function (global, factory) {
	typeof exports === "object" && typeof module !== "undefined"
		? (module.exports = factory(require("jquery"), require("./util.js")))
		: typeof define === "function" && define.amd
			? define(["jquery", "./util"], factory)
			: ((global =
				typeof globalThis !== "undefined" ? globalThis : global || self),
				(global.Collapse = factory(global.jQuery, global.Util)));
})(this, function ($, Util) {
	"use strict";

	function _interopDefaultLegacy(e) {
		return e && typeof e === "object" && "default" in e ? e : { default: e };
	}

	var $__default = /*#__PURE__*/ _interopDefaultLegacy($);
	var Util__default = /*#__PURE__*/ _interopDefaultLegacy(Util);

	function _defineProperties(target, props) {
		for (var i = 0; i < props.length; i++) {
			var descriptor = props[i];
			descriptor.enumerable = descriptor.enumerable || false;
			descriptor.configurable = true;
			if ("value" in descriptor) descriptor.writable = true;
			Object.defineProperty(target, descriptor.key, descriptor);
		}
	}

	function _createClass(Constructor, protoProps, staticProps) {
		if (protoProps) _defineProperties(Constructor.prototype, protoProps);
		if (staticProps) _defineProperties(Constructor, staticProps);
		return Constructor;
	}

	function _extends() {
		_extends =
			Object.assign ||
			function (target) {
				for (var i = 1; i < arguments.length; i++) {
					var source = arguments[i];

					for (var key in source) {
						if (Object.prototype.hasOwnProperty.call(source, key)) {
							target[key] = source[key];
						}
					}
				}

				return target;
			};

		return _extends.apply(this, arguments);
	}

	/**
	 * ------------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------------
	 */

	var NAME = "collapse";
	var VERSION = "4.6.0";
	var DATA_KEY = "bs.collapse";
	var EVENT_KEY = "." + DATA_KEY;
	var DATA_API_KEY = ".data-api";
	var JQUERY_NO_CONFLICT = $__default["default"].fn[NAME];
	var Default = {
		toggle: true,
		parent: "",
	};
	var DefaultType = {
		toggle: "boolean",
		parent: "(string|element)",
	};
	var EVENT_SHOW = "show" + EVENT_KEY;
	var EVENT_SHOWN = "shown" + EVENT_KEY;
	var EVENT_HIDE = "hide" + EVENT_KEY;
	var EVENT_HIDDEN = "hidden" + EVENT_KEY;
	var EVENT_CLICK_DATA_API = "click" + EVENT_KEY + DATA_API_KEY;
	var CLASS_NAME_SHOW = "show";
	var CLASS_NAME_COLLAPSE = "collapse";
	var CLASS_NAME_COLLAPSING = "collapsing";
	var CLASS_NAME_COLLAPSED = "collapsed";
	var DIMENSION_WIDTH = "width";
	var DIMENSION_HEIGHT = "height";
	var SELECTOR_ACTIVES = ".show, .collapsing";
	var SELECTOR_DATA_TOGGLE = '[data-toggle="collapse"]';
	/**
	 * ------------------------------------------------------------------------
	 * Class Definition
	 * ------------------------------------------------------------------------
	 */

	var Collapse = /*#__PURE__*/ (function () {
		function Collapse(element, config) {
			this._isTransitioning = false;
			this._element = element;
			this._config = this._getConfig(config);
			this._triggerArray = [].slice.call(
				document.querySelectorAll(
					'[data-toggle="collapse"][href="#' +
					element.id +
					'"],' +
					('[data-toggle="collapse"][data-target="#' + element.id + '"]')
				)
			);
			var toggleList = [].slice.call(
				document.querySelectorAll(SELECTOR_DATA_TOGGLE)
			);

			for (var i = 0, len = toggleList.length; i < len; i++) {
				var elem = toggleList[i];
				var selector = Util__default["default"].getSelectorFromElement(elem);
				var filterElement = [].slice
					.call(document.querySelectorAll(selector))
					.filter(function (foundElem) {
						return foundElem === element;
					});

				if (selector !== null && filterElement.length > 0) {
					this._selector = selector;

					this._triggerArray.push(elem);
				}
			}

			this._parent = this._config.parent ? this._getParent() : null;

			if (!this._config.parent) {
				this._addAriaAndCollapsedClass(this._element, this._triggerArray);
			}

			if (this._config.toggle) {
				this.toggle();
			}
		} // Getters

		var _proto = Collapse.prototype;

		// Public
		_proto.toggle = function toggle() {
			if ($__default["default"](this._element).hasClass(CLASS_NAME_SHOW)) {
				this.hide();
			} else {
				this.show();
			}
		};

		_proto.show = function show() {
			var _this = this;

			if (
				this._isTransitioning ||
				$__default["default"](this._element).hasClass(CLASS_NAME_SHOW)
			) {
				return;
			}

			var actives;
			var activesData;

			if (this._parent) {
				actives = [].slice
					.call(this._parent.querySelectorAll(SELECTOR_ACTIVES))
					.filter(function (elem) {
						if (typeof _this._config.parent === "string") {
							return elem.getAttribute("data-parent") === _this._config.parent;
						}

						return elem.classList.contains(CLASS_NAME_COLLAPSE);
					});

				if (actives.length === 0) {
					actives = null;
				}
			}

			if (actives) {
				activesData = $__default["default"](actives)
					.not(this._selector)
					.data(DATA_KEY);

				if (activesData && activesData._isTransitioning) {
					return;
				}
			}

			var startEvent = $__default["default"].Event(EVENT_SHOW);
			$__default["default"](this._element).trigger(startEvent);

			if (startEvent.isDefaultPrevented()) {
				return;
			}

			if (actives) {
				Collapse._jQueryInterface.call(
					$__default["default"](actives).not(this._selector),
					"hide"
				);

				if (!activesData) {
					$__default["default"](actives).data(DATA_KEY, null);
				}
			}

			var dimension = this._getDimension();

			$__default["default"](this._element)
				.removeClass(CLASS_NAME_COLLAPSE)
				.addClass(CLASS_NAME_COLLAPSING);
			this._element.style[dimension] = 0;

			if (this._triggerArray.length) {
				$__default["default"](this._triggerArray)
					.removeClass(CLASS_NAME_COLLAPSED)
					.attr("aria-expanded", true);
			}

			this.setTransitioning(true);

			var complete = function complete() {
				$__default["default"](_this._element)
					.removeClass(CLASS_NAME_COLLAPSING)
					.addClass(CLASS_NAME_COLLAPSE + " " + CLASS_NAME_SHOW);
				_this._element.style[dimension] = "";

				_this.setTransitioning(false);

				$__default["default"](_this._element).trigger(EVENT_SHOWN);
			};

			var capitalizedDimension =
				dimension[0].toUpperCase() + dimension.slice(1);
			var scrollSize = "scroll" + capitalizedDimension;
			var transitionDuration = Util__default[
				"default"
			].getTransitionDurationFromElement(this._element);
			$__default["default"](this._element)
				.one(Util__default["default"].TRANSITION_END, complete)
				.emulateTransitionEnd(transitionDuration);
			this._element.style[dimension] = this._element[scrollSize] + "px";
		};

		_proto.hide = function hide() {
			var _this2 = this;

			if (
				this._isTransitioning ||
				!$__default["default"](this._element).hasClass(CLASS_NAME_SHOW)
			) {
				return;
			}

			var startEvent = $__default["default"].Event(EVENT_HIDE);
			$__default["default"](this._element).trigger(startEvent);

			if (startEvent.isDefaultPrevented()) {
				return;
			}

			var dimension = this._getDimension();

			this._element.style[dimension] =
				this._element.getBoundingClientRect()[dimension] + "px";
			Util__default["default"].reflow(this._element);
			$__default["default"](this._element)
				.addClass(CLASS_NAME_COLLAPSING)
				.removeClass(CLASS_NAME_COLLAPSE + " " + CLASS_NAME_SHOW);
			var triggerArrayLength = this._triggerArray.length;

			if (triggerArrayLength > 0) {
				for (var i = 0; i < triggerArrayLength; i++) {
					var trigger = this._triggerArray[i];
					var selector =
						Util__default["default"].getSelectorFromElement(trigger);

					if (selector !== null) {
						var $elem = $__default["default"](
							[].slice.call(document.querySelectorAll(selector))
						);

						if (!$elem.hasClass(CLASS_NAME_SHOW)) {
							$__default["default"](trigger)
								.addClass(CLASS_NAME_COLLAPSED)
								.attr("aria-expanded", false);
						}
					}
				}
			}

			this.setTransitioning(true);

			var complete = function complete() {
				_this2.setTransitioning(false);

				$__default["default"](_this2._element)
					.removeClass(CLASS_NAME_COLLAPSING)
					.addClass(CLASS_NAME_COLLAPSE)
					.trigger(EVENT_HIDDEN);
			};

			this._element.style[dimension] = "";
			var transitionDuration = Util__default[
				"default"
			].getTransitionDurationFromElement(this._element);
			$__default["default"](this._element)
				.one(Util__default["default"].TRANSITION_END, complete)
				.emulateTransitionEnd(transitionDuration);
		};

		_proto.setTransitioning = function setTransitioning(isTransitioning) {
			this._isTransitioning = isTransitioning;
		};

		_proto.dispose = function dispose() {
			$__default["default"].removeData(this._element, DATA_KEY);
			this._config = null;
			this._parent = null;
			this._element = null;
			this._triggerArray = null;
			this._isTransitioning = null;
		}; // Private

		_proto._getConfig = function _getConfig(config) {
			config = _extends({}, Default, config);
			config.toggle = Boolean(config.toggle); // Coerce string values

			Util__default["default"].typeCheckConfig(NAME, config, DefaultType);
			return config;
		};

		_proto._getDimension = function _getDimension() {
			var hasWidth = $__default["default"](this._element).hasClass(
				DIMENSION_WIDTH
			);
			return hasWidth ? DIMENSION_WIDTH : DIMENSION_HEIGHT;
		};

		_proto._getParent = function _getParent() {
			var _this3 = this;

			var parent;

			if (Util__default["default"].isElement(this._config.parent)) {
				parent = this._config.parent; // It's a jQuery object

				if (typeof this._config.parent.jquery !== "undefined") {
					parent = this._config.parent[0];
				}
			} else {
				parent = document.querySelector(this._config.parent);
			}

			var selector =
				'[data-toggle="collapse"][data-parent="' + this._config.parent + '"]';
			var children = [].slice.call(parent.querySelectorAll(selector));
			$__default["default"](children).each(function (i, element) {
				_this3._addAriaAndCollapsedClass(
					Collapse._getTargetFromElement(element),
					[element]
				);
			});
			return parent;
		};

		_proto._addAriaAndCollapsedClass = function _addAriaAndCollapsedClass(
			element,
			triggerArray
		) {
			var isOpen = $__default["default"](element).hasClass(CLASS_NAME_SHOW);

			if (triggerArray.length) {
				$__default["default"](triggerArray)
					.toggleClass(CLASS_NAME_COLLAPSED, !isOpen)
					.attr("aria-expanded", isOpen);
			}
		}; // Static

		Collapse._getTargetFromElement = function _getTargetFromElement(element) {
			var selector = Util__default["default"].getSelectorFromElement(element);
			return selector ? document.querySelector(selector) : null;
		};

		Collapse._jQueryInterface = function _jQueryInterface(config) {
			return this.each(function () {
				var $element = $__default["default"](this);
				var data = $element.data(DATA_KEY);

				var _config = _extends(
					{},
					Default,
					$element.data(),
					typeof config === "object" && config ? config : {}
				);

				if (
					!data &&
					_config.toggle &&
					typeof config === "string" &&
					/show|hide/.test(config)
				) {
					_config.toggle = false;
				}

				if (!data) {
					data = new Collapse(this, _config);
					$element.data(DATA_KEY, data);
				}

				if (typeof config === "string") {
					if (typeof data[config] === "undefined") {
						throw new TypeError('No method named "' + config + '"');
					}

					data[config]();
				}
			});
		};

		_createClass(Collapse, null, [
			{
				key: "VERSION",
				get: function get() {
					return VERSION;
				},
			},
			{
				key: "Default",
				get: function get() {
					return Default;
				},
			},
		]);

		return Collapse;
	})();
	/**
	 * ------------------------------------------------------------------------
	 * Data Api implementation
	 * ------------------------------------------------------------------------
	 */

	$__default["default"](document).on(
		EVENT_CLICK_DATA_API,
		SELECTOR_DATA_TOGGLE,
		function (event) {
			// preventDefault only for <a> elements (which change the URL) not inside the collapsible element
			if (event.currentTarget.tagName === "A") {
				event.preventDefault();
			}

			var $trigger = $__default["default"](this);
			var selector = Util__default["default"].getSelectorFromElement(this);
			var selectors = [].slice.call(document.querySelectorAll(selector));
			$__default["default"](selectors).each(function () {
				var $target = $__default["default"](this);
				var data = $target.data(DATA_KEY);
				var config = data ? "toggle" : $trigger.data();

				Collapse._jQueryInterface.call($target, config);
			});
		}
	);
	/**
	 * ------------------------------------------------------------------------
	 * jQuery
	 * ------------------------------------------------------------------------
	 */

	$__default["default"].fn[NAME] = Collapse._jQueryInterface;
	$__default["default"].fn[NAME].Constructor = Collapse;

	$__default["default"].fn[NAME].noConflict = function () {
		$__default["default"].fn[NAME] = JQUERY_NO_CONFLICT;
		return Collapse._jQueryInterface;
	};

	return Collapse;
});


// ccccc
//
//
if ($(".more-service-slider").length > 0) {
	var moreService = new Swiper(".more-service-slider", {
		slidesPerView: 3,
		spaceBetween: 10,
		loop: true,
		autoplay: {
			delay: 2000,
			disableOnInteraction: false,
		},
		breakpoints: {
			768: {
				slidesPerView: "auto",
				spaceBetween: 40,
			},
			1024: {
				slidesPerView: "auto",
				spaceBetween: 50,
			},
		},
	});
}

if ($('.scroll-container').length > 0) {
	$(".scroll-container").nanoScroller();
}
if ($('.sticky-rules-scroller').length > 0) {
	$(".sticky-rules-scroller").nanoScroller();
}
function toggleNav() {
	var togglerMenu = document.getElementsByTagName("body")[0];
	if (togglerMenu) {
		togglerMenu.classList.toggle("menu-open");
	} else {
	}
}

if ($('#serviceTab').length > 0) {
	$("#serviceTab > a").click(function () {
		$("#serviceTab > a").removeClass('active');
	});
}

if ($('#unitTab').length > 0) {
	$("#unitTab > a").click(function () {
		$("#unitTab > a").removeClass('active');
	});
}

if ($(".m-slider").length > 0) {
	var moreService = new Swiper(".m-slider", {
		slidesPerView: "auto",
		spaceBetween: 10,
		loop: true,
		centeredSlides: true,
		autoplay: {
			delay: 2000,
			disableOnInteraction: false,
		},
		navigation: {
			nextEl: ".job-button-next",
			prevEl: ".job-button-prev",
		},
		breakpoints: {
			768: {
				spaceBetween: 20,
			},
		},
	});
}

if ($(".news-slider").length > 0) {
	var newsService = new Swiper(".news-slider", {
		slidesPerView: 1,
		loop: true,
		autoplay: {
			delay: 2000,
			disableOnInteraction: false,
		},
		pagination: {
			el: ".news-pagination",
		},
	});
}

// home page carousel
if ($(".service-slider-left").length > 0) {
	var newsService = new Swiper(".service-slider-left", {
		slidesPerView: 1,
		loop: true,
		autoplay: {
			delay: 2500,
			disableOnInteraction: false,
		}
	});
}

if ($(".service-slider-right").length > 0) {
	var newsService = new Swiper(".service-slider-right", {
		slidesPerView: "auto",
		spaceBetween: 10,
		loop: true,
		centeredSlides: true,
		autoplay: {
			delay: 2000,
			disableOnInteraction: false,
		}
	});
}

if ($(".vod-service-slider").length > 0) {
	var newsService = new Swiper(".vod-service-slider", {
		slidesPerView: "auto",
		spaceBetween: 30,
		loop: true,
		centeredSlides: true,
		autoplay: {
			delay: 2500,
			disableOnInteraction: false,
		},
		breakpoints: {
			768: {
				spaceBetween: 20,
			},
		},
	});
}


var DOMSCROLL = "DOMMouseScroll";
var SCROLL = "scroll";
var MOUSEWHEEL = "mousewheel";
var TOUCHMOVE = "touchmove";
var DELTA = 20;
var pointers = [];
var animating = false;
var timer;
var currentIndex;
var timer2;

function checkPosition(li) {
	var sc = li.parents('.nano-content').first();
	var liTop = li[0].offsetTop;
	if (sc[0].scrollTop >= liTop || liTop + li[0].offsetHeight >= sc[0].scrollTop + sc[0].clientHeight) {
		sc[0].scrollTop = liTop + li[0].offsetHeight - sc[0].clientHeight;
	}
}

function scrollCheck() {
	var scrollTop = $(window).scrollTop();
	var index = pointers.findIndex(function (p) {
		return Math.max(p.top - DELTA, 0) > scrollTop;
	});
	if (scrollTop < pointers[0].top) {
		index = 1;
	} else {
		index = index >= 0 ? index : pointers.length;
	}
	if (!animating) {
		$(".side-nav li").removeClass("active");
		var li = $(".side-nav li").eq(index - 1);
		li.addClass("active");
		checkPosition(li);
	}

	$(".pointer").removeClass("active");
	$(".pointer")
		.eq(index - 1)
		.addClass("active");
}
$(document).on("click tap", "#menuToggler", function () {
	$('body').toggleClass('menu-open');
});
$(document).ready(function () {
	if ($(".pointer").length > 0) {
		$(".side-nav li").first().addClass("active");
		$(".pointer").each(function () {
			var $p = $(this);
			pointers.push({
				top: $p.position().top,
			});
		});
		scrollCheck();

		$(".side-nav li").click(function (e) {
			e.preventDefault();
			var index = $(this).index();
			var top = $(".pointer").eq(index).position().top;
			$(".pointer").removeClass("active");
			$(".pointer").eq(index).addClass("active");

			$(".side-nav li").removeClass("active");
			var li = $(".side-nav li").eq(index);
			li.addClass("active");
			checkPosition(li);

			animating = true;
			clearTimeout(timer);
			timer = setTimeout(() => {
				animating = false;
			}, 1000);
			$("html, body").animate(
				{
					scrollTop: top,
				},
				0,
				function () { }
			);
		});

		$(window).bind(
			"" + SCROLL + " " + DOMSCROLL + " " + TOUCHMOVE,
			scrollCheck
		);
	}
	$('#stickyBtn').click(function (e) {
		e.preventDefault();
		$(this).parent().toggleClass('is-open')
	});
	$('#stickyClose').click(function (e) {
		e.preventDefault();
		$(this).parents().removeClass('is-open')
	})
	$(window).scroll(function () {
		var c = $(".sticky-rules-wrapper");
		var d = 400;
		if ($(window).scrollTop() + $(window).height() > $(document).height() - d) {
			c.hide();
		} else {
			c.show();
		}
	});
	var fc = $('.newsletter-section').find('.form-control');
	fc.on('keyup', function () {
		if (this.value.length > 1) {
			$(this).addClass('is-typing');
		} else {
			$(this).removeClass('is-typing');
		}
	});
	if ($('#selectJobTab').length > 0) {
		$('#selectJobTab').on('change', function (e) {
			$("#unitTab > a").removeClass('active');
			$('#unitTab > a').eq($(this).val()).tab('show');
		});
	}
	if ($('#selectFaqTab').length > 0) {
		$('#selectFaqTab').on('change', function (e) {
			$("#serviceTab > a").removeClass('active');
			$('#serviceTab > a').eq($(this).val()).tab('show');
		});
	}
});
$(document).mouseup(function (e) {
	var container = $(".sticky-rules-wrapper");

	// if the target of the click isn't the container nor a descendant of the container
	if (!container.is(e.target) && container.has(e.target).length === 0) {
		container.removeClass('is-open');
	}
});


if ($("#wcupSlider").length > 0) {
	let wcupSlider = $("#wcupSlider");
	let flag = wcupSlider.find('.flag-container');
	for (let index = 0; index < flag.length; index++) {
		const element = flag[index];
		element.querySelectorAll('.flag-tools').forEach(el => {
			let startTime = el.getAttribute('data-startDate');
			startTime = Date.parse(startTime)
			let now = new Date().getTime();

			if (now < startTime) {
				let x = setInterval(function () {
					let now = new Date().getTime();
					let distance = startTime - now;

					let days = Math.floor(distance / (1000 * 60 * 60 * 24));
					let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
					let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
					let seconds = Math.floor((distance % (1000 * 60)) / 1000);

					el.querySelector('.time-elapse').innerHTML = "<div>" + days + "<span>روز</span></div>" + "<div>" + hours + "<span>ساعت</span></div>"
						+ "<div>" + minutes + "<span>دقیقه</span></div>" + "<div>" + seconds + "<span>ثانیه</span></div>";

					if (distance < 0) {
						clearInterval(x);
						el.querySelector('.time-elapse').innerHTML = "برگزار شده";
					}
				}, 1000);
			}
		})
	}
};